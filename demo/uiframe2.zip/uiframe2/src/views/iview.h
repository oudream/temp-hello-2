#ifndef MCT_IVIEW_H
#define MCT_IVIEW_H

#include <QWidget>
#include <QVariantMap>

class IView : public QWidget {
Q_OBJECT
public:
    explicit IView(QWidget *parent=nullptr) : QWidget(parent) {}
    virtual ~IView() {}
signals:
    void viewEvent(const QString &type, const QVariant &payload);
public slots:
    virtual void setActionStates(const QVariantMap &states) { Q_UNUSED(states); }
};

#endif // MCT_IVIEW_H
