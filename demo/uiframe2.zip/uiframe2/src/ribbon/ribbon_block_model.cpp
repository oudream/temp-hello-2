// ribbon_block_model.cpp
#include "ribbon_block_model.h"

RibbonBlockModel::RibbonBlockModel(QObject *parent) : QObject(parent) {}

void RibbonBlockModel::registerBlock(BlockId id, const RibbonBlockDef &def) {
    m_defs.insert(id, def);
}
