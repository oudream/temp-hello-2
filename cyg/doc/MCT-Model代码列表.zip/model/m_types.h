/// @file mtypes.h

#ifndef M_TYPES_H
#define M_TYPES_H

#include <cstdint>

/**
 * @enum ObjectType
 * @brief 定义模型对象的类型枚举。
 * @details 每个枚举值占用16位，将作为 MId 的高位部分。
 */
enum class MObjectType : uint16_t
{
    None = 0,
    Scene,
    Volume,
    KnifePlane,
    SliceSet,
    RenderStyle,
    Camera,
    MeasureItem,
    // ... 可持续扩展
};

/**
 * @union MId
 * @brief 带类型标签的64位唯一ID。
 * @details
 * 作用：为系统中所有 MObject 提供一个带有类型信息的唯一标识符。
 * 结构：
 * - 高16位: ObjectType (类型标签)
 * - 低48位: Instance Index (实例索引)
 */
union MId
{
    uint64_t full_id; /// < 完整的64位ID

    struct
    {
        uint64_t index : 48; /// < 实例索引 (低48位)
        uint64_t type  : 16; /// < 对象类型 (高16位)
    } parts;

    // 默认构造函数
    MId() : full_id(0) {}
    // 从完整ID构造
    explicit MId(uint64_t id) : full_id(id) {}

    /**
     * @brief 从类型和索引构造 MId。
     * @param objType 对象类型。
     * @param objIndex 实例索引。
     */
    MId(MObjectType objType, uint64_t objIndex)
    {
        full_id = 0; // 先清零
        parts.type = static_cast<uint16_t>(objType);
        parts.index = objIndex;
    }

    /**
     * @brief 获取ID中的类型信息。
     * @return ObjectType 对象类型枚举。
     */
    MObjectType getType() const { return static_cast<MObjectType>(parts.type); }

    /**
     * @brief 获取ID中的实例索引。
     * @return uint64_t 实例索引。
     */
    uint64_t getIndex() const { return parts.index; }

    // 为了方便在map等容器中使用，重载操作符
    bool operator<(const MId& other) const { return full_id < other.full_id; }
    bool operator==(const MId& other) const { return full_id == other.full_id; }
    bool operator!=(const MId& other) const { return full_id != other.full_id; }
};

#endif // M_TYPES_H