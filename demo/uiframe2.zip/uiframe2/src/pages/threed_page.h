// threed_page.h
#ifndef MCT_THREED_PAGE_H
#define MCT_THREED_PAGE_H

#include "ipage.h"
#include "../views/four_view_widget.h"

class ThreeDPage : public IPage {
Q_OBJECT
public:
    explicit ThreeDPage(QWidget *parent=nullptr);
    PageId pageId() const override { return PageId::ThreeD; }
    QString title() const override { return tr("3D"); }

    FourViewWidget* fourView() const { return m_four; }

private:
    FourViewWidget *m_four = nullptr;
};

#endif // MCT_THREED_PAGE_H
