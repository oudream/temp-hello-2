#ifndef UV_TCP_CLIENT_H
#define UV_TCP_CLIENT_H

#include <cxthread.h>
#include <cxchannel.h>


class UVTcpClient : public CxIChannelSubject
{
public:
    static UVTcpClient* start(const std::string &sRemoteIp, int iRemotePort);

    static int sendData(const unsigned char *pData, int iLength);

public:
    UVTcpClient();
    ~UVTcpClient();

protected:
    bool channel_canChangeConnect(const CxChannelBase *oChannel, bool bOldConnect, bool bNewConnect);

    void channel_connectChanged(const CxChannelBase *oChannel);

    void channel_beforeDelete(const CxChannelBase *oChannel);

    void channel_receivedData(const uchar *pData, int iLength, void *oSource);

    void channel_roadConnectChanged(const CxChannelBase *oChannel, CxChannelRoad *oChannelRoad, bool bRemove);

private:
    int open(const std::string &sRemoteIp, int iRemotePort);

    void close();

private:
    CxChannelBase * _channel;

};

#endif //UV_TCP_CLIENT_H
