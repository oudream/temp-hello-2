#ifndef MCT_UTIL_H
#define MCT_UTIL_H

// 四视图布局
enum class FourViewLayout {
    Grid2x2,
    OneAndThree
};

#endif // MCT_UTIL_H
