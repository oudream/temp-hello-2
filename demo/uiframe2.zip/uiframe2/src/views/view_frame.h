#ifndef MCT_VIEW_FRAME_H
#define MCT_VIEW_FRAME_H

#include <QGraphicsView>
#include <QGraphicsScene>
#include <QScrollBar>
#include <QToolButton>
#include <QLabel>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPainter>
#include "iview.h"

// 中央画布：隐藏自身滚动条，外部提供滚动与按钮
class CTGraphicsView : public QGraphicsView {
Q_OBJECT
public:
    explicit CTGraphicsView(QWidget *parent=nullptr);
public slots:
    void zoomIn();
    void zoomOut();
    void fitToViewKeep();
};

// 单个小窗（含标题、外部滚动条 + 小按钮、中央画布）
class ViewFrame : public IView {
Q_OBJECT
public:
    explicit ViewFrame(const QString &title, QWidget *parent=nullptr);
    CTGraphicsView* graphicsView() const { return m_view; }

private:
    static QToolButton* makeBtn(const QString &text);

private:
    CTGraphicsView *m_view = nullptr;
    QScrollBar *m_hbar = nullptr;
    QScrollBar *m_vbar = nullptr;
};

#endif // MCT_VIEW_FRAME_H
