// inspect_page.h
#ifndef MCT_INSPECT_PAGE_H
#define MCT_INSPECT_PAGE_H

#include "ipage.h"
#include <QVBoxLayout>
#include <QLabel>

class InspectPage : public IPage {
Q_OBJECT
public:
    explicit InspectPage(QWidget *parent=nullptr) : IPage(parent) {
        QVBoxLayout *v = new QVBoxLayout(this);
        v->addWidget(new QLabel("试检页（占位）"));
        v->addStretch();
    }
    PageId pageId() const override { return PageId::Inspect; }
    QString title() const override { return tr("试检"); }
};

#endif // MCT_INSPECT_PAGE_H
