// reconstruct_page.h
#ifndef MCT_RECONSTRUCT_PAGE_H
#define MCT_RECONSTRUCT_PAGE_H

#include "ipage.h"
#include <QVBoxLayout>
#include <QLabel>

class ReconstructPage : public IPage {
Q_OBJECT
public:
    explicit ReconstructPage(QWidget *parent=nullptr) : IPage(parent) {
        QVBoxLayout *v = new QVBoxLayout(this);
        v->addWidget(new QLabel("重建页（占位）"));
        v->addStretch();
    }
    PageId pageId() const override { return PageId::Reconstruct; }
    QString title() const override { return tr("重建"); }
};

#endif // MCT_RECONSTRUCT_PAGE_H
