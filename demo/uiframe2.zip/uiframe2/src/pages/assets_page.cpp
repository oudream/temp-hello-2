// assets_page.cpp
#include "assets_page.h"
