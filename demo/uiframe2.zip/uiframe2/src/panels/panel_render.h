// panel_render.h
#ifndef MCT_PANEL_RENDER_H
#define MCT_PANEL_RENDER_H

#include "ipanel.h"
#include <QFormLayout>
#include <QComboBox>
#include <QDoubleSpinBox>

class PanelRender : public IPanel {
Q_OBJECT
public:
    explicit PanelRender(QWidget *parent=nullptr) : IPanel(parent) {
        QFormLayout *f = new QFormLayout(this);
        QComboBox *mode = new QComboBox;
        mode->addItems({tr("体渲染"), tr("MIP"), tr("表面")});
        QDoubleSpinBox *op = new QDoubleSpinBox;
        op->setRange(0.0, 1.0); op->setSingleStep(0.05); op->setValue(0.6);
        f->addRow(tr("模式："), mode);
        f->addRow(tr("不透明度："), op);
        setMinimumWidth(260);
    }
};

#endif // MCT_PANEL_RENDER_H
