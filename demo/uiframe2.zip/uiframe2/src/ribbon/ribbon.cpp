// ribbon.cpp
#include "ribbon.h"
#include <QVBoxLayout>
#include <QLabel>

static QWidget* wrapScrollable(QWidget *w) {
    QScrollArea *sa = new QScrollArea;
    sa->setWidgetResizable(true);
    sa->setFrameShape(QFrame::NoFrame);
    sa->setWidget(w);
    return sa;
}

QToolButton* Ribbon::makeBigBtn(const QString &text, const QIcon &icon) {
    QToolButton *b = new QToolButton;
    b->setDefaultAction(new QAction(icon, text, b));
    b->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
    b->setFixedSize(QSize(84, 70));
    return b;
}

QWidget* Ribbon::makeGroupWidget(const RibbonGroup &grp) {
    QWidget *box = new QWidget;
    QVBoxLayout *v = new QVBoxLayout(box);
    v->setContentsMargins(6,6,6,6);
    v->setSpacing(6);

    QLabel *title = new QLabel(grp.title);
    QFont f = title->font(); f.setBold(true);
    title->setFont(f);

    QWidget *row = new QWidget;
    QHBoxLayout *h = new QHBoxLayout(row);
    h->setContentsMargins(0,0,0,0);
    h->setSpacing(6);
    for (QAction *a : grp.actions) {
        QToolButton *btn = new QToolButton;
        btn->setDefaultAction(a);
        btn->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
        btn->setFixedSize(QSize(76, 60));
        h->addWidget(btn);
    }
    h->addStretch();

    v->addWidget(title);
    v->addWidget(row);
    return box;
}

Ribbon::Ribbon(QWidget *parent) : QWidget(parent) {
    // 先创建常用动作（布局/面板），供模型复用
    actLayoutGrid = new QAction(QIcon(), tr("2×2布局"), this);
    actLayout13   = new QAction(QIcon(), tr("1&3布局"), this);
    actEqualize   = new QAction(QIcon(), tr("等分"), this);
    actToggleProperty = new QAction(QIcon(), tr("属性"), this);
    actToggleRender   = new QAction(QIcon(), tr("渲染"), this);
    actToggleLog      = new QAction(QIcon(), tr("日志"), this);

    connect(actLayoutGrid, &QAction::triggered, this, &Ribbon::requestLayoutGrid);
    connect(actLayout13,   &QAction::triggered, this, &Ribbon::requestLayout13);
    connect(actEqualize,   &QAction::triggered, this, &Ribbon::requestEqualize);
    connect(actToggleProperty, &QAction::triggered, this, [this]{ emit requestTogglePanel("Property"); });
    connect(actToggleRender,   &QAction::triggered, this, [this]{ emit requestTogglePanel("Render"); });
    connect(actToggleLog,      &QAction::triggered, this, [this]{ emit requestTogglePanel("Log"); });

    QVBoxLayout *outer = new QVBoxLayout(this);
    outer->setContentsMargins(6,4,6,4);
    outer->setSpacing(4);

    m_topBar = buildTopBlocks();
    outer->addWidget(m_topBar);

    m_bottomBar = new QWidget;
    m_bottomScroll = new QScrollArea;
    m_bottomScroll->setWidgetResizable(true);
    m_bottomScroll->setFrameShape(QFrame::NoFrame);
    m_bottomScroll->setWidget(m_bottomBar);
    outer->addWidget(m_bottomScroll, 1);
}

QWidget* Ribbon::buildTopBlocks() {
    QWidget *w = new QWidget;
    QHBoxLayout *h = new QHBoxLayout(w);
    h->setContentsMargins(4,0,4,0);
    h->setSpacing(6);

    auto addBlock = [&](const QString &text, BlockId id){
        QToolButton *btn = makeBigBtn(text);
        connect(btn->defaultAction(), &QAction::triggered, this, [this,id]{ switchBlock(id); });
        h->addWidget(btn);
    };

    // 顶部功能块：项目、原图、重建、3D、试检、体编、体选、切面、渲染、测量、分割、配准、窗体、转换
    addBlock(tr("项目"), BlockId::Project);
    addBlock(tr("原图"), BlockId::Assets);
    addBlock(tr("重建"), BlockId::Reconstruct);
    addBlock(tr("3D"),   BlockId::ThreeD);
    addBlock(tr("试检"), BlockId::Inspect);
    // 进入 3D 页 的功能块
    addBlock(tr("体编"), BlockId::VoxelEdit);
    addBlock(tr("体选"), BlockId::VoxelSelect);
    addBlock(tr("切面"), BlockId::Slice);
    addBlock(tr("渲染"), BlockId::Render);
    addBlock(tr("测量"), BlockId::Measure);
    addBlock(tr("分割"), BlockId::Segment);
    addBlock(tr("配准"), BlockId::Register);
    addBlock(tr("窗体"), BlockId::Windowing);
    addBlock(tr("转换"), BlockId::Convert);

    h->addStretch();
    return w;
}

QWidget* Ribbon::buildBottomGroups(BlockId id) {
    // 依据当前块，装配分组 UI
    QWidget *container = new QWidget;
    QHBoxLayout *h = new QHBoxLayout(container);
    h->setContentsMargins(6,2,6,2);
    h->setSpacing(10);

    if (!m_model.hasBlock(id)) {
        h->addWidget(new QLabel(tr("未注册的功能块")));
        h->addStretch();
        return container;
    }

    const RibbonBlockDef def = m_model.def(id);
    for (const RibbonGroup &grp : def.groups) {
        h->addWidget(makeGroupWidget(grp));
    }
    h->addStretch();
    return container;
}

void Ribbon::switchBlock(BlockId id) {
    m_currentBlock = id;

    // 路由：非 3D 系列 → 切到对应页；3D 系列 → 切到 3D 页
    PageId target = PageId::ThreeD;
    if (id == BlockId::Project)     target = PageId::Project;
    else if (id == BlockId::Assets) target = PageId::Assets;
    else if (id == BlockId::Reconstruct) target = PageId::Reconstruct;
    else if (id == BlockId::Inspect)     target = PageId::Inspect;
    emit requestSwitchPage(target);

    // 下层分组切换
    QWidget *newBottom = buildBottomGroups(id);
    m_bottomScroll->takeWidget();
    m_bottomBar->deleteLater();
    m_bottomBar = newBottom;
    m_bottomScroll->setWidget(m_bottomBar);
}
