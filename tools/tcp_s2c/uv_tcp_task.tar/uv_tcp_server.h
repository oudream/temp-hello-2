#ifndef UV_TCP_SERVER_H
#define UV_TCP_SERVER_H

#include <uv.h>


class UVTcpServer
{
public:
    static int start(int iListenPort);

    static int sendData(const unsigned char *pData, int iLength);

    static void stop();

};


#endif //UV_TCP_SERVER_H
