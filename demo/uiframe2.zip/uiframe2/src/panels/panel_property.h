// panel_property.h
#ifndef MCT_PANEL_PROPERTY_H
#define MCT_PANEL_PROPERTY_H

#include "ipanel.h"
#include <QVBoxLayout>
#include <QLabel>

class PanelProperty : public IPanel {
Q_OBJECT
public:
    explicit PanelProperty(QWidget *parent=nullptr) : IPanel(parent) {
        QVBoxLayout *v = new QVBoxLayout(this);
        v->addWidget(new QLabel("属性（占位）"));
        v->addStretch();
        setMinimumWidth(240);
    }
};

#endif // MCT_PANEL_PROPERTY_H
