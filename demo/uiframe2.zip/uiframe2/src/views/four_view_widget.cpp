#include "four_view_widget.h"
#include <QVBoxLayout>
#include <QHBoxLayout>

FourViewWidget::FourViewWidget(QWidget *parent) : QWidget(parent) {
    m_vTL = new ViewFrame("Axial", this);
    m_vTR = new ViewFrame("Sagittal", this);
    m_vBL = new ViewFrame("Coronal", this);
    m_vBR = new ViewFrame("3D", this);
    rebuild();
}

void FourViewWidget::setLayoutMode(FourViewLayout mode) {
    if (m_mode == mode) return;
    m_mode = mode;
    rebuild();
}

void FourViewWidget::equalizeCells() {
    // 使用 splitter 的 setSizes 等方式等分；这里用简单策略：重建布局达到等分效果
    rebuild();
}

void FourViewWidget::resizeEvent(QResizeEvent *e) {
    QWidget::resizeEvent(e);
    // 窗口大小变化后，保持等分（当前策略：重建布局）
    // 为避免频繁重建，这里直接调用 equalizeCells（你需要更精细可优化）
    // equalizeCells(); // 可选
}

void FourViewWidget::rebuild() {
    if (m_currLayout) {
        delete m_currLayout;
        m_currLayout = nullptr;
    }

    if (m_mode == FourViewLayout::Grid2x2) {
        QGridLayout *g = new QGridLayout;
        g->setContentsMargins(2,2,2,2);
        g->setSpacing(2);
        g->addWidget(m_vTL, 0, 0);
        g->addWidget(m_vTR, 0, 1);
        g->addWidget(m_vBL, 1, 0);
        g->addWidget(m_vBR, 1, 1);
        setLayout(g);
        m_currLayout = g;
    } else {
        // 1&3：左大（TL），右侧三小垂直排列（TR/BR/BL 的顺序你可自定义）
        QWidget *center = new QWidget;
        QHBoxLayout *h = new QHBoxLayout(center);
        h->setContentsMargins(2,2,2,2);
        h->setSpacing(2);

        h->addWidget(m_vTL, 2);

        QWidget *right = new QWidget;
        QVBoxLayout *v = new QVBoxLayout(right);
        v->setContentsMargins(0,0,0,0);
        v->setSpacing(2);
        v->addWidget(m_vTR, 1);
        v->addWidget(m_vBR, 1);
        v->addWidget(m_vBL, 1);

        h->addWidget(right, 1);

        QVBoxLayout *outer = new QVBoxLayout;
        outer->setContentsMargins(0,0,0,0);
        outer->setSpacing(0);
        outer->addWidget(center);

        setLayout(outer);
        m_currLayout = outer;
    }
}
