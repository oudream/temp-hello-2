/// @file mobject.h

#ifndef M_OBJECT_H
#define M_OBJECT_H

#include "m_types.h" // 引入新的类型定义

/**
 * @class MObject
 * @brief (已更新) 模型层所有数据对象的统一抽象基类。
 * @details
 * 作用：为场景中的所有对象提供一个共同的接口和基础属性。
 * 职责边界：只负责定义对象本身的基础状态，如唯一的 MId 和存活状态。
 * 核心原理/数据流：每个对象由 MScene 创建并持有所有权。外部通过指针或引用访问。
 */
class MObject
{
public:
    using IdType = MId; // IdType 现在是 MId 联合体

    /**
     * @brief 构造函数。
     * @param id 由 MScene 分配的唯一 MId。
     */
    explicit MObject(IdType id) : _id(id), _alive(true) {}

    virtual ~MObject() = default;

    MObject(const MObject&) = delete;
    MObject& operator=(const MObject&) = delete;
    MObject(MObject&&) = delete;
    MObject& operator=(MObject&&) = delete;

    /**
     * @brief 获取对象的唯一 MId。
     * @return IdType 对象的ID。
     */
    IdType getId() const { return _id; }

    /**
     * @brief 获取对象的类型。
     * @return ObjectType 这是一个纯虚函数，强制派生类实现。
     */
    virtual MObjectType getType() const = 0;

    bool isAlive() const { return _alive; }

protected:
    friend class MScene;
    void markAsDead() { _alive = false; }

private:
    const IdType _id;
    bool _alive;

};

#endif // M_OBJECT_H