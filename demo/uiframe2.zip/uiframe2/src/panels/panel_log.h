// panel_log.h
#ifndef MCT_PANEL_LOG_H
#define MCT_PANEL_LOG_H

#include "ipanel.h"
#include <QPlainTextEdit>
#include <QVBoxLayout>

class PanelLog : public IPanel {
Q_OBJECT
public:
    explicit PanelLog(QWidget *parent=nullptr) : IPanel(parent) {
        QVBoxLayout *v = new QVBoxLayout(this);
        QPlainTextEdit *log = new QPlainTextEdit;
        log->setReadOnly(true);
        log->setPlainText("[Log] 系统初始化完成…");
        v->addWidget(log);
        setMinimumWidth(260);
    }
};

#endif // MCT_PANEL_LOG_H
