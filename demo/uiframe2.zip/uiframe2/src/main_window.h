// main_window.h
#ifndef MCT_MAIN_WINDOW_H
#define MCT_MAIN_WINDOW_H

#include <QMainWindow>
#include <QStackedWidget>
#include "app_ids.h"
#include "ribbon/ribbon.h"
#include "panels/panel_manager.h"
#include "pages/ipage.h"
#include "pages/threed_page.h"

class MainWindow : public QMainWindow {
Q_OBJECT
public:
    explicit MainWindow(QWidget *parent=nullptr);

private:
    void setupPages();
    void setupPanels();
    void setupRibbonModel();

private slots:
    void switchToPage(PageId id);
    void onLayoutGrid();
    void onLayout13();
    void onEqualize();
    void onTogglePanel(const QString &id);

private:
    Ribbon *m_ribbon = nullptr;
    QStackedWidget *m_stack = nullptr;
    PanelManager *m_panels = nullptr;

    // 页索引
    QMap<PageId,int> m_pageIndex;
    // 访问 3D 页的 fourView
    ThreeDPage* page3D() const;
};

#endif // MCT_MAIN_WINDOW_H
