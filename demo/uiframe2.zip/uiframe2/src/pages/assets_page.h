// assets_page.h
#ifndef MCT_ASSETS_PAGE_H
#define MCT_ASSETS_PAGE_H

#include "ipage.h"
#include <QVBoxLayout>
#include <QLabel>

class AssetsPage : public IPage {
Q_OBJECT
public:
    explicit AssetsPage(QWidget *parent=nullptr) : IPage(parent) {
        QVBoxLayout *v = new QVBoxLayout(this);
        v->addWidget(new QLabel("原图页（占位）"));
        v->addStretch();
    }
    PageId pageId() const override { return PageId::Assets; }
    QString title() const override { return tr("原图"); }
};

#endif // MCT_ASSETS_PAGE_H
