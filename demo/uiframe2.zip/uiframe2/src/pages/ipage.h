#ifndef MCT_IPAGE_H
#define MCT_IPAGE_H

#include <QWidget>
#include "../app_ids.h"

// 页基类：可扩展“进入/离开时机”等钩子
class IPage : public QWidget {
Q_OBJECT
public:
    explicit IPage(QWidget *parent=nullptr) : QWidget(parent) {}
    virtual ~IPage() {}

    virtual PageId pageId() const = 0;
    virtual QString title() const = 0;

public slots:
    virtual void onEnter() {}  // 切入该页时
    virtual void onLeave() {}  // 离开该页时
};

#endif // MCT_IPAGE_H
