// ribbon_block_model.h
#ifndef MCT_RIBBON_BLOCK_MODEL_H
#define MCT_RIBBON_BLOCK_MODEL_H

#include <QObject>
#include <QMap>
#include <QVector>
#include <QString>
#include <QAction>
#include "../app_ids.h"

// 下层分组 = 组名 + 动作列表
struct RibbonGroup {
    QString title;
    QList<QAction*> actions;
};

// 功能块定义
struct RibbonBlockDef {
    QString displayName;     // 功能块显示名（如“体编”）
    PageId targetPage;       // 点击后切换的页
    QVector<RibbonGroup> groups; // 下层分组（按所选块切换）
};

class RibbonBlockModel : public QObject {
Q_OBJECT
public:
    explicit RibbonBlockModel(QObject *parent=nullptr);
    void registerBlock(BlockId id, const RibbonBlockDef &def);
    bool hasBlock(BlockId id) const { return m_defs.contains(id); }
    RibbonBlockDef def(BlockId id) const { return m_defs.value(id); }

private:
    QMap<BlockId, RibbonBlockDef> m_defs;
};

#endif // MCT_RIBBON_BLOCK_MODEL_H
