/// @file mscene.h

#ifndef M_SCENE_H
#define M_SCENE_H

#include "m_object.h"
#include <memory>
#include <vector>
#include <map> // 用于存储每种类型的下一个实例索引

/**
 * @class MScene
 * @brief (已更新) 核心场景类，管理所有模型对象的生命周期。
 * @details
 * 作用：作为模型层数据的中央存储库，统一创建、管理和销毁所有 MObject 派生类的实例。
 * 核心原理/数据流：内部使用 std::unique_ptr 持有所有权。
 * ID 分配机制更新为分类型生成 MId。
 */
class MScene
{
public:
    MScene() = default;
    ~MScene() = default;

    MScene(const MScene&) = delete;
    MScene& operator=(const MScene&) = delete;
    MScene(MScene&&) = delete;
    MScene& operator=(MScene&&) = delete;

    /**
     * @brief 创建一个 MObject 派生类的对象实例。
     * @tparam T MObject的派生类。
     * @tparam Args 派生类构造函数的参数类型。
     * @param args 派生类构造函数的参数。
     * @return T* 指向新创建对象的裸指针。调用方不获得所有权。
     * @note 线程安全性：非线程安全，必须在主线程调用。
     */
    template<typename T, typename... Args>
    T* createObject(Args&&... args)
    {
        static_assert(std::is_base_of<MObject, T>::value, "T must be derived from MObject");

        // 为了获取类型，我们需要一个 T 的临时实例或静态方法。
        // 一个更简单、更明确的方法是让 T 提供一个静态的 Type 成员。
        // 例如： class MVolume { public: static const ObjectType Type = ObjectType::Volume; ... }
        // 这里我们先用一个临时对象来获取类型，后续可以优化。
        T temp_for_type_deduction(MId(), std::forward<Args>(args)...);
        MObjectType type = temp_for_type_deduction.getType();

        // 生成新的 MId
        uint64_t nextIndex = _nextInstanceIds[type]++;
        MId newId(type, nextIndex);

        // 创建对象并传递 MId
        auto newObjectPtr = std::make_unique<T>(newId, std::forward<Args>(args)...);

        T* rawPtr = newObjectPtr.get();
        _objects.push_back(std::move(newObjectPtr));

        return rawPtr;
    }

    MObject* findObject(MId id) const;
    bool eraseObject(MId id);
    void collectGarbage();

private:
    /// 存储所有对象的容器
    std::vector<std::unique_ptr<MObject>> _objects;

    /// 存储每种 ObjectType 的下一个可用实例索引
    std::map<MObjectType, uint64_t> _nextInstanceIds;
};

#endif // M_SCENE_H