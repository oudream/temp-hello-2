// threed_page.cpp
#include "threed_page.h"
#include <QHBoxLayout>

ThreeDPage::ThreeDPage(QWidget *parent) : IPage(parent) {
    m_four = new FourViewWidget(this);
    QHBoxLayout *h = new QHBoxLayout(this);
    h->setContentsMargins(4,4,4,4);
    h->addWidget(m_four, 1);
}
