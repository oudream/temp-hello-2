#ifndef CX_CT_X2_UTIL_H
#define CX_CT_X2_UTIL_H

#pragma once
enum class FourViewLayout { Grid2x2, OneAndThree };


#endif //CX_CT_X2_UTIL_H
