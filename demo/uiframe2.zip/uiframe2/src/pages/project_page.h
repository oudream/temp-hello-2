// project_page.h
#ifndef MCT_PROJECT_PAGE_H
#define MCT_PROJECT_PAGE_H

#include "ipage.h"
#include <QVBoxLayout>
#include <QLabel>

class ProjectPage : public IPage {
Q_OBJECT
public:
    explicit ProjectPage(QWidget *parent=nullptr) : IPage(parent) {
        QVBoxLayout *v = new QVBoxLayout(this);
        v->addWidget(new QLabel("项目页（占位）"));
        v->addStretch();
    }
    PageId pageId() const override { return PageId::Project; }
    QString title() const override { return tr("项目"); }
};

#endif // MCT_PROJECT_PAGE_H
