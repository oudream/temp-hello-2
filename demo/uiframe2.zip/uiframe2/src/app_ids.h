#ifndef MCT_APP_IDS_H
#define MCT_APP_IDS_H

// 页（中央 Stacked 页）
enum class PageId {
    Project,   // 项目
    Assets,    // 原图
    Reconstruct, // 重建
    ThreeD,    // 3D
    Inspect    // 试检
};

// 功能块（Ribbon 上层大按钮）
enum class BlockId {
    Project,
    Assets,
    Reconstruct,
    ThreeD,
    Inspect,
    // 以下功能块点击后均切到 3D 页
    VoxelEdit,     // 体编
    VoxelSelect,   // 体选
    Slice,         // 切面
    Render,        // 渲染
    Measure,       // 测量
    Segment,       // 分割
    Register,      // 配准
    Windowing,     // 窗体（布局/面板）
    Convert        // 转换
};

#endif // MCT_APP_IDS_H
