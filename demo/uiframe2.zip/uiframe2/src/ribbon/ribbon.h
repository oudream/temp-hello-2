// ribbon.h
#ifndef MCT_RIBBON_H
#define MCT_RIBBON_H

#include <QWidget>
#include <QToolButton>
#include <QScrollArea>
#include <QTabWidget>
#include <QHBoxLayout>
#include "ribbon_block_model.h"
#include "../app_ids.h"

// 两层：上层功能块（大按钮区），下层功能名（分组区）
class Ribbon : public QWidget {
Q_OBJECT
public:
    explicit Ribbon(QWidget *parent=nullptr);

    // 注册模型（由 MainWindow 注入并填充）
    RibbonBlockModel* model() { return &m_model; }

signals:
    // 切换页（主窗处理）
    void requestSwitchPage(PageId id);

    // 四视图布局（属于“窗体/通用”的常用动作）
    void requestLayoutGrid();
    void requestLayout13();
    void requestEqualize();

    // 面板显隐
    void requestTogglePanel(const QString &id); // "Property" / "Render" / "Log"

public slots:
    // 切换到某个功能块（驱动下层分组重建）
    void switchBlock(BlockId id);

private:
    QWidget* buildTopBlocks();           // 上层：功能块大按钮条
    QWidget* buildBottomGroups(BlockId); // 下层：功能名分组条
    static QToolButton* makeBigBtn(const QString &text, const QIcon &icon=QIcon());
    static QWidget* makeGroupWidget(const RibbonGroup &grp);

private:
    RibbonBlockModel m_model;
    // UI 容器
    QWidget *m_topBar = nullptr;
    QWidget *m_bottomBar = nullptr;
    QScrollArea *m_bottomScroll = nullptr;
    // 当前选中
    BlockId m_currentBlock = BlockId::ThreeD;
    // 预置一些通用 QAction（窗体/面板），供模型使用
public:
    QAction *actLayoutGrid = nullptr;
    QAction *actLayout13 = nullptr;
    QAction *actEqualize = nullptr;
    QAction *actToggleProperty = nullptr;
    QAction *actToggleRender = nullptr;
    QAction *actToggleLog = nullptr;

    // 暴露一个便捷函数：外部可调用模拟点击某块
public:
    void activateBlock(BlockId id) { switchBlock(id); }
};

#endif // MCT_RIBBON_H
