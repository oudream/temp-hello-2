// main_window.cpp
#include "main_window.h"

#include "pages/project_page.h"
#include "pages/assets_page.h"
#include "pages/reconstruct_page.h"
#include "pages/inspect_page.h"

#include "panels/panel_property.h"
#include "panels/panel_render.h"
#include "panels/panel_log.h"

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent) {
    // Ribbon + Stacked 中央
    QWidget *central = new QWidget;
    QVBoxLayout *v = new QVBoxLayout(central);
    v->setContentsMargins(0,0,0,0);
    v->setSpacing(0);

    m_ribbon = new Ribbon(this);
    v->addWidget(m_ribbon);

    m_stack = new QStackedWidget(this);
    v->addWidget(m_stack, 1);

    setCentralWidget(central);

    // 页、面板、Ribbon 模型
    setupPages();
    setupPanels();
    setupRibbonModel();

    // 连接 Ribbon 信号
    connect(m_ribbon, &Ribbon::requestSwitchPage, this, &MainWindow::switchToPage);
    connect(m_ribbon, &Ribbon::requestLayoutGrid, this, &MainWindow::onLayoutGrid);
    connect(m_ribbon, &Ribbon::requestLayout13,   this, &MainWindow::onLayout13);
    connect(m_ribbon, &Ribbon::requestEqualize,   this, &MainWindow::onEqualize);
    connect(m_ribbon, &Ribbon::requestTogglePanel,this, &MainWindow::onTogglePanel);

    // 默认 3D
    switchToPage(PageId::ThreeD);
    // 初始块：3D（或你想默认“窗体”）
    m_ribbon->activateBlock(BlockId::ThreeD);
}

void MainWindow::setupPages() {
    auto add = [&](IPage *p){
        int idx = m_stack->addWidget(p);
        m_pageIndex.insert(p->pageId(), idx);
    };
    add(new ProjectPage(this));
    add(new AssetsPage(this));
    add(new ReconstructPage(this));
    add(new ThreeDPage(this));
    add(new InspectPage(this));
}

void MainWindow::setupPanels() {
    m_panels = new PanelManager(this);
    m_panels->addPanel("Property", new PanelProperty(this), tr("属性"));
    m_panels->addPanel("Render",   new PanelRender(this),   tr("渲染"));
    m_panels->addPanel("Log",      new PanelLog(this),      tr("日志"));
}

void MainWindow::setupRibbonModel() {
    // 在下一条消息里补：把每个功能块的“下层分组与动作”注册进 model
    // 这里先注册“窗体”块示例（布局/面板）
    auto &rm = *m_ribbon->model();

    // 窗体（进入 3D），含：布局、面板显隐
    {
        RibbonBlockDef def;
        def.displayName = tr("窗体");
        def.targetPage = PageId::ThreeD;
        RibbonGroup gLayout{ tr("布局"), { m_ribbon->actLayoutGrid, m_ribbon->actLayout13, m_ribbon->actEqualize } };
        RibbonGroup gPanel { tr("面板"), { m_ribbon->actToggleProperty, m_ribbon->actToggleRender, m_ribbon->actToggleLog } };
        def.groups = { gLayout, gPanel };
        rm.registerBlock(BlockId::Windowing, def);
    }

    // 其它块先注册空分组，下一条消息里一次性补齐
    auto regEmpty = [&](BlockId id, PageId pg, const QString &name){
        RibbonBlockDef def; def.displayName = name; def.targetPage = pg;
        rm.registerBlock(id, def);
    };
    regEmpty(BlockId::Project,     PageId::Project,     tr("项目"));
    regEmpty(BlockId::Assets,      PageId::Assets,      tr("原图"));
    regEmpty(BlockId::Reconstruct, PageId::Reconstruct, tr("重建"));
    regEmpty(BlockId::ThreeD,      PageId::ThreeD,      tr("3D"));
    regEmpty(BlockId::Inspect,     PageId::Inspect,     tr("试检"));

    // 3D 系列：
    regEmpty(BlockId::VoxelEdit,   PageId::ThreeD, tr("体编"));
    regEmpty(BlockId::VoxelSelect, PageId::ThreeD, tr("体选"));
    regEmpty(BlockId::Slice,       PageId::ThreeD, tr("切面"));
    regEmpty(BlockId::Render,      PageId::ThreeD, tr("渲染"));
    regEmpty(BlockId::Measure,     PageId::ThreeD, tr("测量"));
    regEmpty(BlockId::Segment,     PageId::ThreeD, tr("分割"));
    regEmpty(BlockId::Register,    PageId::ThreeD, tr("配准"));
    regEmpty(BlockId::Convert,     PageId::ThreeD, tr("转换"));
}

void MainWindow::switchToPage(PageId id) {
    int idx = m_pageIndex.value(id, -1);
    if (idx >= 0) m_stack->setCurrentIndex(idx);
}

ThreeDPage* MainWindow::page3D() const {
    int idx = m_pageIndex.value(PageId::ThreeD, -1);
    if (idx < 0) return nullptr;
    return qobject_cast<ThreeDPage*>(m_stack->widget(idx));
}

void MainWindow::onLayoutGrid()  { if (auto p = page3D()) p->fourView()->setLayoutMode(FourViewLayout::Grid2x2); }
void MainWindow::onLayout13()    { if (auto p = page3D()) p->fourView()->setLayoutMode(FourViewLayout::OneAndThree); }
void MainWindow::onEqualize()    { if (auto p = page3D()) p->fourView()->equalizeCells(); }

void MainWindow::onTogglePanel(const QString &id) { m_panels->togglePanel(id); }
