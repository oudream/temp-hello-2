// panel_log.cpp
#include "panel_log.h"
