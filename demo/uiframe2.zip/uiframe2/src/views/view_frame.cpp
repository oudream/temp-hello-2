#include "view_frame.h"

CTGraphicsView::CTGraphicsView(QWidget *parent) : QGraphicsView(parent) {
    setScene(new QGraphicsScene(this));
    setRenderHints(QPainter::Antialiasing | QPainter::SmoothPixmapTransform);
    setDragMode(QGraphicsView::ScrollHandDrag);
    setBackgroundBrush(QColor(45,45,48));
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    // 棋盘格占位，便于观察缩放/滚动
    const int s = 20, n = 20;
    QImage img(s*n, s*n, QImage::Format_ARGB32_Premultiplied);
    img.fill(Qt::transparent);
    QPainter p(&img);
    for (int y=0; y<n; ++y)
        for (int x=0; x<n; ++x)
            p.fillRect(x*s, y*s, s, s, ((x+y)%2==0)?QColor(70,70,70):QColor(55,55,55));
    p.end();
    scene()->addPixmap(QPixmap::fromImage(img));
    setSceneRect(0,0,img.width(), img.height());
}

void CTGraphicsView::zoomIn()  { scale(1.2, 1.2); }
void CTGraphicsView::zoomOut() { scale(1/1.2, 1/1.2); }
void CTGraphicsView::fitToViewKeep() { fitInView(sceneRect(), Qt::KeepAspectRatio); }

static QWidget* makeTitleBar(const QString &title) {
    QLabel *lbl = new QLabel(title);
    lbl->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
    lbl->setFixedHeight(18);
    QWidget *w = new QWidget;
    auto *h = new QHBoxLayout(w);
    h->setContentsMargins(2,2,2,2);
    h->addWidget(lbl);
    h->addStretch();
    return w;
}

QToolButton* ViewFrame::makeBtn(const QString &text){
    QToolButton *b = new QToolButton;
    b->setText(text);
    b->setToolButtonStyle(Qt::ToolButtonTextOnly);
    b->setFixedHeight(22);
    return b;
}

ViewFrame::ViewFrame(const QString &title, QWidget *parent) : IView(parent) {
    auto *outer = new QVBoxLayout(this);
    outer->setContentsMargins(2,2,2,2);
    outer->setSpacing(2);

    // 标题栏
    outer->addWidget(makeTitleBar(title));

    // 中央行：画布 + 右侧按钮/竖滚动条
    auto *center = new QHBoxLayout;
    center->setContentsMargins(0,0,0,0);
    center->setSpacing(2);

    m_view = new CTGraphicsView(this);
    center->addWidget(m_view, 1);

    QWidget *rightBar = new QWidget;
    auto *rv = new QVBoxLayout(rightBar);
    rv->setContentsMargins(0,0,0,0);
    rv->setSpacing(2);

    // 右侧小按钮（+ / - / 适应）
    QToolButton *btnPlus = makeBtn("+");
    QToolButton *btnMinus= makeBtn("-");
    QToolButton *btnFit  = makeBtn("适应");
    rv->addWidget(btnPlus);
    rv->addWidget(btnMinus);
    rv->addWidget(btnFit);
    rv->addSpacing(6);

    m_vbar = new QScrollBar(Qt::Vertical);
    rv->addWidget(m_vbar, 1);

    center->addWidget(rightBar);
    outer->addLayout(center, 1);

    // 底部：缩小/放大/合适 + 横滚动条
    QWidget *bottom = new QWidget;
    auto *bh = new QHBoxLayout(bottom);
    bh->setContentsMargins(0,0,0,0);
    bh->setSpacing(4);
    QToolButton *btnZOut = makeBtn("缩小");
    QToolButton *btnZIn  = makeBtn("放大");
    QToolButton *btnFit2 = makeBtn("合适");
    bh->addWidget(btnZOut);
    bh->addWidget(btnZIn);
    bh->addWidget(btnFit2);
    bh->addSpacing(4);
    m_hbar = new QScrollBar(Qt::Horizontal);
    bh->addWidget(m_hbar, 1);
    outer->addWidget(bottom);

    // 滚动条联动（外部 <-> 内部）
    connect(m_hbar, &QScrollBar::valueChanged, this, [this](int v){
        m_view->horizontalScrollBar()->setValue(v);
    });
    connect(m_view->horizontalScrollBar(), &QScrollBar::rangeChanged, this, [this](int a,int b){
        m_hbar->setRange(a,b);
    });
    connect(m_view->horizontalScrollBar(), &QScrollBar::valueChanged, m_hbar, &QScrollBar::setValue);

    connect(m_vbar, &QScrollBar::valueChanged, this, [this](int v){
        m_view->verticalScrollBar()->setValue(v);
    });
    connect(m_view->verticalScrollBar(), &QScrollBar::rangeChanged, this, [this](int a,int b){
        m_vbar->setRange(a,b);
    });
    connect(m_view->verticalScrollBar(), &QScrollBar::valueChanged, m_vbar, &QScrollBar::setValue);

    // 缩放/适配按钮
    connect(btnPlus,  &QToolButton::clicked, m_view, &CTGraphicsView::zoomIn);
    connect(btnMinus, &QToolButton::clicked, m_view, &CTGraphicsView::zoomOut);
    connect(btnFit,   &QToolButton::clicked, m_view, &CTGraphicsView::fitToViewKeep);
    connect(btnZIn,   &QToolButton::clicked, m_view, &CTGraphicsView::zoomIn);
    connect(btnZOut,  &QToolButton::clicked, m_view, &CTGraphicsView::zoomOut);
    connect(btnFit2,  &QToolButton::clicked, m_view, &CTGraphicsView::fitToViewKeep);
}
