#ifndef MCT_FOUR_VIEW_WIDGET_H
#define MCT_FOUR_VIEW_WIDGET_H

#include <QWidget>
#include <QGridLayout>
#include <QSplitter>
#include "view_frame.h"
#include "../util.h"

// 四视图容器：支持 2x2 与 1&3；提供“等分”功能
class FourViewWidget : public QWidget {
Q_OBJECT
public:
    explicit FourViewWidget(QWidget *parent=nullptr);
    void setLayoutMode(FourViewLayout mode);
    FourViewLayout layoutMode() const { return m_mode; }
    void equalizeCells(); // 等分

    // 暴露视图句柄（便于后续联动）
    ViewFrame* viewTL() const { return m_vTL; }
    ViewFrame* viewTR() const { return m_vTR; }
    ViewFrame* viewBL() const { return m_vBL; }
    ViewFrame* viewBR() const { return m_vBR; }

protected:
    void resizeEvent(QResizeEvent *e) override;

private:
    void rebuild(); // 依据 m_mode 重建布局

private:
    FourViewLayout m_mode = FourViewLayout::Grid2x2;
    ViewFrame *m_vTL = nullptr; // 左上（Axial）
    ViewFrame *m_vTR = nullptr; // 右上（Sagittal）
    ViewFrame *m_vBL = nullptr; // 左下（Coronal）
    ViewFrame *m_vBR = nullptr; // 右下（3D）
    QLayout *m_currLayout = nullptr;
};

#endif // MCT_FOUR_VIEW_WIDGET_H
